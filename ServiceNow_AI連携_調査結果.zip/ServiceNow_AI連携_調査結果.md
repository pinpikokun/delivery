# ServiceNow × AIエージェント連携 調査結果

調査日: 2026年2月28日

---

## 背景

ServiceNow上でのIncident起票やChange Request作成をAIエージェントに任せたい。現環境ではMicrosoft Entra ID経由のSSOでServiceNowに接続しており、普段は認証を意識せず利用できている。

---

## 選択肢の全体像

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│  ┌─────────────────────────┐    ┌─────────────────────────────┐    │
│  │  選択肢1（外部連携）      │    │  選択肢2（内蔵AI）           │    │
│  │  ⚠ 非推奨               │    │  ★ 推奨                     │    │
│  │                         │    │                             │    │
│  │  GitHub Copilot         │    │  ServiceNow UI              │    │
│  │    ↓                    │    │    ↓                        │    │
│  │  MCPサーバー（自前構築）  │    │  Now Assist（内蔵AI）        │    │
│  │    ↓                    │    │    ↓                        │    │
│  │  REST API（認証が課題）  │    │  直接操作（SSOそのまま）     │    │
│  │    ↓                    │    │    ↓                        │    │
│  │  ServiceNow             │    │  ServiceNow                 │    │
│  └─────────────────────────┘    └─────────────────────────────┘    │
│                                                                     │
│     手間が多く現実的でない ✗          シンプルで導入しやすい ✓       │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 選択肢1：外部MCPサーバー経由 ⚠ 非推奨

GitHub Copilot等のAIクライアントから、MCPサーバーを経由してServiceNowを操作する方式。

技術的には可能だが、SSO環境では現実的でない。MCPサーバーはREST APIを叩くためSSOが使えず、OAuth Client CredentialsやAPI Keyを管理者に別途発行してもらう必要がある。MCPサーバーの構築・運用も自前で行うことになり、認証情報を設定ファイルに持つことでセキュリティ上のリスクも生まれる。Incident/Changeの起票という目的に対して、導入コストが見合わない。

```
┌───────────┐     stdio     ┌──────────────┐     HTTPS      ┌──────────────┐
│  GitHub   │ ────────────→ │              │ ─────────────→ │              │
│  Copilot  │               │  MCPサーバー   │   REST API     │  ServiceNow  │
│           │ ←──────────── │ （自分のPC上） │ ←───────────── │  インスタンス  │
└───────────┘               └──────┬───────┘                 └──────────────┘
                                   │
                                   │ ⚠ OAuth / API Key 等の
                                   │   認証情報が必要（SSOは使えない）
                                   │ ⚠ 認証情報を平文で管理するリスク
                                   │ ⚠ MCPサーバーの構築・運用が必要
                                   ▼
                            ┌──────────────┐
                            │ 管理者に発行  │
                            │ を依頼する    │
                            │ 必要あり      │
                            └──────────────┘
```

---

## 選択肢2：ServiceNow内蔵AIエージェント（Now Assist） ★ 推奨

ServiceNowプラットフォームに内蔵されたAIエージェント（Now Assist）を使う方式。ServiceNowのUI上で動作するため、SSOがそのまま使える。サーバー構築もAPI認証も不要で、既存の業務フローを変えずにAIを導入できる。Incident/Change起票という目的に対して最も直接的かつ現実的な選択肢。

```
┌──────────────────────────────────────────────────────┐
│                 ServiceNow プラットフォーム             │
│                                                      │
│   ┌──────────┐         ┌───────────────────┐        │
│   │          │  SSO    │                   │        │
│   │  あなた   │ ──────→ │   ServiceNow UI   │        │
│   │（ブラウザ）│  認証   │                   │        │
│   │          │ そのまま │   ┌─────────────┐ │        │
│   └──────────┘         │   │  Now Assist  │ │        │
│                        │   │  AIエージェント│ │        │
│                        │   └──────┬──────┘ │        │
│                        └──────────┼────────┘        │
│                                   │                  │
│                                   ▼                  │
│                        ┌───────────────────┐        │
│                        │ Incident / Change │        │
│                        │ を直接作成・更新    │        │
│                        └───────────────────┘        │
│                                                      │
│  ★ SSOがそのまま使える（認証の追加設定なし）            │
│  ★ サーバー構築・運用が不要                            │
│  ★ 既存の業務フローをそのまま活かせる                   │
└──────────────────────────────────────────────────────┘
```

ただし Now Assist SKU（Pro Plus / Enterprise Plus）の契約が必要。会社が契約済みなら利用可能、未契約なら利用できない。

---

## 結論と次のアクション

SSO環境でIncident/Changeの起票をAIに任せるなら、Now Assistが最も現実的な選択肢。まずはServiceNow管理者にNow Assist SKUの契約状況を確認する。

---

## 参考リンク

| 情報源 | URL |
|---|---|
| ServiceNow MCP & A2A FAQ（公式コミュニティ） | https://www.servicenow.com/community/now-assist-articles/enable-mcp-and-a2a-for-your-agentic-workflows-with-faqs-updated/ta-p/3373907 |
| echelon-ai-labs/servicenow-mcp（GitHub） | https://github.com/echelon-ai-labs/servicenow-mcp |
| MCP公式ドキュメント | https://modelcontextprotocol.io/docs/getting-started/intro |
